export interface User {
  id: string;
  email: string;
  role: 'admin' | 'faculty' | 'student' | 'staff';
  firstName?: string;
  lastName?: string;
}

export interface SensorData {
  id: string;
  type: 'energy' | 'water' | 'occupancy' | 'temperature';
  value: number;
  unit: string;
  timestamp: string;
  location: string;
}

export interface Alert {
  id: string;
  type: 'security' | 'maintenance' | 'energy' | 'system';
  severity: 'low' | 'medium' | 'high';
  message: string;
  timestamp: string;
  status: 'active' | 'resolved';
}