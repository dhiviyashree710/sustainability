import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Download, Filter } from 'lucide-react';

const mockData = [
  { month: 'Jan', energy: 4000, water: 2400, waste: 2400 },
  { month: 'Feb', energy: 3000, water: 1398, waste: 2210 },
  { month: 'Mar', energy: 2000, water: 9800, waste: 2290 },
  { month: 'Apr', energy: 2780, water: 3908, waste: 2000 },
  { month: 'May', energy: 1890, water: 4800, waste: 2181 },
  { month: 'Jun', energy: 2390, water: 3800, waste: 2500 },
];

const Reports = () => {
  return (
    <div className="space-y-6">
      <div className="sm:flex sm:items-center sm:justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Sustainability Reports</h2>
          <p className="mt-1 text-sm text-slate-500">Monthly analysis and trends</p>
        </div>
        <div className="mt-4 sm:mt-0 space-x-3">
          <button className="inline-flex items-center px-4 py-2 border border-slate-300 rounded-md shadow-sm text-sm font-medium text-slate-700 bg-white hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-emerald-500">
            <Filter className="h-4 w-4 mr-2" />
            Filter
          </button>
          <button className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-emerald-600 hover:bg-emerald-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-emerald-500">
            <Download className="h-4 w-4 mr-2" />
            Export
          </button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-3">
        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="p-5">
            <div className="flex items-center">
              <div className="w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-slate-500 truncate">Total Energy Savings</dt>
                  <dd className="flex items-baseline">
                    <div className="text-2xl font-semibold text-slate-900">15.3%</div>
                    <div className="ml-2 flex items-baseline text-sm font-semibold text-emerald-600">
                      <span>vs last year</span>
                    </div>
                  </dd>
                </dl>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="p-5">
            <div className="flex items-center">
              <div className="w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-slate-500 truncate">Water Conservation</dt>
                  <dd className="flex items-baseline">
                    <div className="text-2xl font-semibold text-slate-900">12.8%</div>
                    <div className="ml-2 flex items-baseline text-sm font-semibold text-emerald-600">
                      <span>improvement</span>
                    </div>
                  </dd>
                </dl>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="p-5">
            <div className="flex items-center">
              <div className="w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-slate-500 truncate">Waste Reduction</dt>
                  <dd className="flex items-baseline">
                    <div className="text-2xl font-semibold text-slate-900">8.4%</div>
                    <div className="ml-2 flex items-baseline text-sm font-semibold text-emerald-600">
                      <span>decrease</span>
                    </div>
                  </dd>
                </dl>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Chart */}
      <div className="bg-white shadow rounded-lg p-6">
        <h3 className="text-lg font-medium text-slate-900 mb-4">Resource Usage Trends</h3>
        <div className="h-96">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={mockData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="energy" fill="#059669" />
              <Bar dataKey="water" fill="#0ea5e9" />
              <Bar dataKey="waste" fill="#8b5cf6" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};

export default Reports;